# SAPPORO CENTRAL INFO Ver.2.1

札幌市中央区の飲食店「開店・閉店」とイベントを自動収集し、
毎朝09:00 JSTにLINEへ通知する構成です。

## ファイル

- `index.html` : 閲覧画面（`data/items.json` を自動で読み込んで表示）
- `collector.py` : 自動収集＋重複除外＋LINE通知
- `data/items.json` : 収集済みデータの永続ストア（ワークフローが自動更新）
- `.github/workflows/daily.yml` : 毎朝09:00 JSTの自動実行
- `LINE_SETUP.md` : LINE設定手順

## 動作

```
Google News RSS
  ↓
中央区関連を抽出
  ↓
新店・閉店・イベントに分類
  ↓
data/items.json の既存IDと突き合わせて「本当に新しい記事」だけ抽出
  ↓
data/items.json を更新してリポジトリにコミット（永続化）
  ↓
新着があった場合のみ、LINEへ朝9時にダイジェスト送信
```

Ver.2 からの変更点（2点）:

1. **重複通知の防止**：`data/items.json` に収集済み全件を蓄積し、前回までに送信済みのIDを除外してから通知するようにした。ワークフローが `data/items.json` をリポジトリへコミットするため、実行のたびに状態が保持される。
2. **`index.html` との接続**：`index.html` が `data/items.json` を `fetch` して一覧表示するようにした。GitHub Pages等で公開すればブラウザから最新の収集結果を確認できる。取得に失敗した場合はサンプルデータにフォールバックする。既読・お気に入りの状態はID単位でブラウザのlocalStorageに保存され、データ更新の影響を受けない。

## 公開する場合

このリポジトリでGitHub Pagesを有効にすると、`index.html` から同一リポジトリ内の `data/items.json` を相対パスで読み込めます（Settings → Pages → Branch を指定）。

次のVer.3では、情報源の固定巡回、AIによる住所・店名・日付抽出、Supabase等への保存、過去通知との重複排除の高度化を追加すると、かなり実用的になります。
